VC98linker, comes from a part of VC6 (Microsoft Visual C++ 6.0, with sp6).

It only includes the linker(link.exe), libraries(*.lib), and the corresponding programs.

There is NO compiler, IDE, debug libraries, and include files.

It can only be used for test, study or research, to prohibit commercial.

Extract to any folder, and you can use it, make youself happy:)

THIS IS A THIRD-PARTY SOFTWARE. IT IS PROVIDED "AS IS", WITHOUT ANY WARRANTY.

If it does not meet your needs, please install the full version of VC6, comes from Microsoft official.

Best wishes to you.


2009/12/28
vc98linker@gmail.com
