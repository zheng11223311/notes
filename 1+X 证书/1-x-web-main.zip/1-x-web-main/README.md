# Web-1+x
web 前端开发等级考证模拟

# 下载 & 拉取
 - 方法一：直接 DownLoad Zip
 - 方法二：`git clone https://github.com/Lydever/web-1-x.git`

共5套完整的模拟卷：
![图片](https://user-images.githubusercontent.com/65069676/138794485-0da23cd0-d855-4274-9ddf-67e74137f5fc.png)
![图片](https://user-images.githubusercontent.com/65069676/138795044-094a405b-a7f9-4ffa-9857-7a981e529e89.png)



注意：这是根据2020年的考纲出的模拟题，今年2021是1+x试点第三年了，自己注意考纲技术要求~

# 考点知识回顾:

[一. 1+X Web前端中级必考 | PHP 技术与应用](https://blog.csdn.net/weixin_43853746/article/details/108928068)

[二. 1+X Web前端等级考证 | 详解jQuery基础 ](https://blog.csdn.net/weixin_43853746/article/details/108916725)

[三. 1+X Web前端等级考证 | 深入浅出MySQL数据库](https://blog.csdn.net/weixin_43853746/article/details/109585844)

[四. 1+X Web前端等级考证 | Web中级12月最新模拟题](https://blog.csdn.net/weixin_43853746/article/details/109686767)

[1+X Web前端等级考证 | 2020 12月Web前端开发中级理论 (试卷1) 附答案](https://blog.csdn.net/weixin_43853746/article/details/109991848)

[1+X Web前端等级考证 | 2020 12月Web前端开发中级实操 (试卷1) 附答案](https://blog.csdn.net/weixin_43853746/article/details/109992935)

[1+X Web前端等级考证 | 2020 12月Web前端开发中级理论 (试卷2) 附答案](https://blog.csdn.net/weixin_43853746/article/details/109895005)

[1+X Web前端等级考证 | 2020 12月Web前端开发中级实操 (试卷2) 附答案](https://blog.csdn.net/weixin_43853746/article/details/109895208)

[1+X Web前端等级考证 | 2020 12月Web前端开发中级实操 (试卷3) 附答案](https://blog.csdn.net/weixin_43853746/article/details/109754127)

[1+X Web前端等级考证 | 2020 12月Web前端开发中级理论 (试卷3) 附答案](https://blog.csdn.net/weixin_43853746/article/details/109754600)

[1+X Web前端等级考证 | 2020 12月Web前端开发中级实操 (试卷4) 附答案](https://blog.csdn.net/weixin_43853746/article/details/109752494)

[1+X Web前端等级考证 | 2020 12月Web前端开发中级理论 (试卷4) 附答案](https://blog.csdn.net/weixin_43853746/article/details/109752094)

[1+X Web前端等级考证 | 2020 12月Web前端开发中级实操 (试卷5) 附答案](https://blog.csdn.net/weixin_43853746/article/details/109753433)

[1+X Web前端等级考证 | 2020 12月Web前端开发中级理论 (试卷5) 附答案](https://blog.csdn.net/weixin_43853746/article/details/109752995)
