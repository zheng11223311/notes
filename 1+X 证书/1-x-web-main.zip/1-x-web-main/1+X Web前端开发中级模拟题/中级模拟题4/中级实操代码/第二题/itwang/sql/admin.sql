INSERT INTO `admin` VALUES (1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'admin@qq.com');
INSERT INTO `admin` VALUES (2, 'zhangsan', '01d7f40760960e7bd9443513f22ab9af', 'zhangsan@qq.com');
INSERT INTO `admin` VALUES (3, 'lisi1', '14e4c78b7cb219d72264d2872de81905', 'lisi@qq.com');
INSERT INTO `admin` VALUES (4, 'wangwu', '9f001e4166cf26bfbdd3b4f67d9ef617', 'wangwu@qq.com');
