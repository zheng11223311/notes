<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
{{-- 在（7）（8） （9） （10）处填写合适代码 --}}
    （7） ($data  as （8） )
        <div>
        <h1>{{$item->title}}</h1>
        {{$item->author}}
        <hr>
        <p>
           {{（9）->content}}
        </p>
        </div>
    （10）



</body>
</html>