<?php

//在（1）处补齐代码， 使用视图方法渲染welcome模板
Route::get('/', function () {
    return （1）('welcome');
});

//在（2）处补齐代码， url匹配/info,交给IndexController的info方法处理
Route::get('/info', "         （2）         ");



