<?php
Route::get('/', function () {
    return view('welcome');
});
Route::get('/main','____(1)_____');		//根据UserControoler中的写法填写（2分）