<?php
//エラーメッセージ， ja-jp.php
return [
    'require_name' => 'ユーザ名は空ではいけません！',
    'email_error'  => 'メールアドレスが間違っています！',
];