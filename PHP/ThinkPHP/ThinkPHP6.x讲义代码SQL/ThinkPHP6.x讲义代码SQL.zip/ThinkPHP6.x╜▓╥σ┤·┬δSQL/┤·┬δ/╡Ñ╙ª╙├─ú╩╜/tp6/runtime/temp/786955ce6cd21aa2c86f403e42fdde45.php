<?php /*a:1:{s:42:"C:\wamp\www\tp6\view\store\middleware.html";i:1583422895;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>

模版区域

</body>
</html>