<?php
namespace app\model;
use think\model\Pivot;

class Access extends Pivot
{

}