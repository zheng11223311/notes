<?php /*a:1:{s:36:"C:\wamp\www\tp6\view\show\index.html";i:1582626630;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>

模版<?php echo htmlentities($name); ?>.<?php echo htmlentities($email); ?>

</body>
</html>