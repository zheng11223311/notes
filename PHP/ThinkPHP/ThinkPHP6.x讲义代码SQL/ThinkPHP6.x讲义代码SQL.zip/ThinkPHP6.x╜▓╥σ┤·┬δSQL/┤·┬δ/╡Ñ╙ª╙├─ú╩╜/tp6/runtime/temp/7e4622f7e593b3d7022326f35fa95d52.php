<?php /*a:1:{s:40:"C:\wamp\www\tp6\view\show\condition.html";i:1582804999;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>

<?php switch($number): case "1":case "2":case "3":case "4": ?>上<?php break; case "5":case "6":case "7":case "8": ?>中<?php break; case $id: ?>下<?php break; default: ?>不存在
<?php endswitch; if(($number >= 10) OR ($number > 5)): ?>
    OK
<?php elseif($number < 5): ?>
    OOK
<?php else: ?>
    NOT OK
<?php endif; if(strtoupper($name) == 'MR.LEE'): ?>
    相等
<?php endif; if(in_array(($number), explode(',',"10,20,30,40,50"))): ?>
存在
<?php else: ?>
不存在
<?php endif; $_RANGE_VAR_=explode(',',"10,50");if($number>= $_RANGE_VAR_[0] && $number<= $_RANGE_VAR_[1]):?>存在<?php endif; if(isset($number)): ?>变量已定义<?php endif; ?>


</body>
</html>