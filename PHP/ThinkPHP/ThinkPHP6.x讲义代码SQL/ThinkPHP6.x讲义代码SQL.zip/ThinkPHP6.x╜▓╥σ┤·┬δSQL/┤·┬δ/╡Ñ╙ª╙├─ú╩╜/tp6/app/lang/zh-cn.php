<?php
//错误信息，zh-cn.php
return [
    'require_name' => '用户名不得为空！',
    'email_error'  => '邮箱地址不正确！',
    'user'  =>  [
        'login'     =>  '登录成功',
        'logout'    =>  '退出成功'
    ]
];