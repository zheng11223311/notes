<?php /*a:1:{s:35:"C:\wamp\www\tp6\view\show\loop.html";i:1582800751;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>

<table border="1" align="center" width="700">
    <tr>
        <th>编号</th>
        <th>姓名</th>
        <th>性别</th>
        <th>邮箱</th>
        <th>价格</th>
        <th>时间</th>
    </tr>
    <?php foreach($list as $key=>$obj): if($obj->username == '樱桃小丸子'): ?>
    <tr>
        <td><?php echo htmlentities($key); ?>/<?php echo htmlentities($obj->id); ?></td>
        <td><?php echo htmlentities($obj->username); ?></td>
        <td><?php echo htmlentities($obj->gender); ?></td>
        <td><?php echo htmlentities($obj->email); ?></td>
        <td><?php echo htmlentities($obj->price); ?></td>
        <td><?php echo htmlentities($obj->create_time); ?></td>
    </tr>
    <?php endif; ?>
    <?php endforeach; ?>
</table>

<table border="1" align="center" width="700">
    <tr>
        <th>编号</th>
        <th>姓名</th>
        <th>性别</th>
        <th>邮箱</th>
        <th>价格</th>
        <th>时间</th>
    </tr>
    
    
    
    <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $k = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$obj): $mod = ($k % 2 );++$k;?>
    <tr>
        <td><?php echo htmlentities($k); ?>/<?php echo htmlentities($obj->id); ?></td>
        <td><?php echo htmlentities($obj->username); ?></td>
        <td><?php echo htmlentities($obj->gender); ?></td>
        <td><?php echo htmlentities($obj->email); ?></td>
        <td><?php echo htmlentities($obj->price); ?></td>
        <td><?php echo htmlentities($obj->create_time); ?></td>
    </tr>
    
    <?php endforeach; endif; else: echo "" ;endif; ?>
</table>

<?php $__FOR_START_1852606173__=100;$__FOR_END_1852606173__=1;for($i=$__FOR_START_1852606173__;$i > $__FOR_END_1852606173__;$i+=-2){ ?>
    <?php echo htmlentities($i); } ?>



</body>
</html>