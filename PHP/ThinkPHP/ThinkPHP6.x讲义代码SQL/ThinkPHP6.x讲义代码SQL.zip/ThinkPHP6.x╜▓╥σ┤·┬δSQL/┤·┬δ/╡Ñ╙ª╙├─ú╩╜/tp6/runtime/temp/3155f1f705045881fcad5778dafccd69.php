<?php /*a:1:{s:37:"C:\wamp\www\tp6\view\show\output.html";i:1582773171;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>

<?php echo htmlentities((isset($arr['name']) && ($arr['name'] !== '')?$arr['name']:'没有姓名')); ?>--<?php echo htmlentities($arr['age']); ?>
<br>
<?php echo htmlentities($obj->name); ?>--<?php echo htmlentities($obj->age); ?>--<?php echo htmlentities($obj->fn()); ?>--<?php echo htmlentities($obj::PI); ?>
<br>
<?php echo htmlentities(app('request')->get('id')); ?>
<?php echo htmlentities(app('request')->param('id')); ?>
<?php echo htmlentities(app('request')->host()); ?>
<?php echo htmlentities(PHP_VERSION); ?>
<?php echo htmlentities(PHP_VERSION); ?>
<?php echo htmlentities(config('app.app_host')); ?>
<?php echo htmlentities(config('session.name')); ?>
<br>

<?php echo md5($password); ?>--<?php echo htmlentities(date('Y-m-d',!is_numeric($time)? strtotime($time) : $time)); ?>
<br>
<?php echo htmlentities(substr($arr['name'],0,3)); ?>--<?php echo md5(substr($arr['name'], 0, 3)); ?>
<br>
<?php echo htmlentities(md5($number + $number)); ?>
<br>
<?php echo !empty($arr['name']) ? '正确'  :  '错误'; if(!empty($arr['name'])) echo '真'; ?>
<?php echo (htmlentities(app('request')->get('id'))) ? htmlentities(app('request')->get('id')) :  '不存在'; ?>
<?php echo !empty($arr['name']) ? htmlentities($arr['name']) : '不存在'; ?>

</body>
</html>