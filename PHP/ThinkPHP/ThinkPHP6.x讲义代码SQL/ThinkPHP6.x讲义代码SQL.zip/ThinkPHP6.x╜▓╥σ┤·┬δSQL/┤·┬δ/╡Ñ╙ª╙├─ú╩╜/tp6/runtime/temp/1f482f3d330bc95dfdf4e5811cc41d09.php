<?php /*a:1:{s:36:"C:\wamp\www\tp6\view\page\index.html";i:1583309774;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <style>
        .pagination {
            list-style: none;
            margin: 0;
            padding: 0;
        }
        .pagination li {
            padding: 20px;
            display: inline-block;
        }
    </style>
</head>
<body>

<table border="1" align="center" width="700">
    <tr>
        <th>编号</th>
        <th>姓名</th>
        <th>性别</th>
        <th>邮箱</th>
        <th>价格</th>
        <th>时间</th>
    </tr>
    <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$obj): $mod = ($i % 2 );++$i;?>
    <tr>
        <td><?php echo htmlentities($obj->id); ?></td>
        <td><?php echo htmlentities($obj->username); ?></td>
        <td><?php echo htmlentities($obj->gender); ?></td>
        <td><?php echo htmlentities($obj->email); ?></td>
        <td><?php echo htmlentities($obj->price); ?></td>
        <td><?php echo htmlentities($obj->create_time); ?></td>
    </tr>
    <?php endforeach; endif; else: echo "" ;endif; ?>
</table>

<?php echo $list; ?>

</body>
</html>