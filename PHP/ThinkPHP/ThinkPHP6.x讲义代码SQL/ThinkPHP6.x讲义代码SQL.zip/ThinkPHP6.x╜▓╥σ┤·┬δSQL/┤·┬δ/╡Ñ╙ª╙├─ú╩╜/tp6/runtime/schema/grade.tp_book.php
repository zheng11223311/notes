<?php 
return array (
  'id' => 'int',
  'user_id' => 'int',
  'title' => 'string',
  '_pk' => 'id',
  '_autoinc' => 'id',
);