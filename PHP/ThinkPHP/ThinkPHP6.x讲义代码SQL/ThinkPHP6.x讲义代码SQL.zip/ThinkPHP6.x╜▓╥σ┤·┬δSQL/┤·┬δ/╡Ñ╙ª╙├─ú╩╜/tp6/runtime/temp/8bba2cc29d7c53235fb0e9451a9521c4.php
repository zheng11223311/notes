<?php /*a:1:{s:38:"C:\wamp\www\tp6\view\store\upload.html";i:1583222724;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>

<form action="http://localhost/tp6/public/upload/index" method="post" enctype="multipart/form-data">
    <input type="file" name="image">
    <input type="submit" value="上传">
</form>

<!--<form action="http://localhost/tp6/public/upload/more" method="post" enctype="multipart/form-data">-->
<!--    <input type="file" name="image[]">-->
<!--    <input type="file" name="image[]">-->
<!--    <input type="file" name="image[]">-->
<!--    <input type="submit" value="上传">-->
<!--</form>-->


</body>
</html>