<?php
return [
    \app\service\ShutService::class
];