<?php 
return array (
  'id' => 'int',
  'user_id' => 'int',
  'hobby' => 'string',
  'status' => 'int',
  '_pk' => 'id',
  '_autoinc' => 'id',
);