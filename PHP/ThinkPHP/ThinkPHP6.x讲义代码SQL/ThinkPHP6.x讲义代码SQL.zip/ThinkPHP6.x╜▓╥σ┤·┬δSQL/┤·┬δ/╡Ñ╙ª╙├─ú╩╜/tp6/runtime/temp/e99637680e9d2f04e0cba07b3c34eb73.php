<?php /*a:1:{s:45:"C:\wamp\www\tp6\view\..\public\test\test.html";i:1581997491;}*/ ?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
	<meta charset="UTF-8">
	<title>模拟提交</title>
</head>
<body>


<input type="button" id="button" value="确定">
<div id="show"></div>

<!--<form action="http://localhost/tp6/public/rely/get" method="post">-->
<!--	<input type="text" name="name" value="Lee">-->
<!--	<input type="hidden" name="_method" value="PUT">-->
<!--	<input type="submit" value="提交">-->
<!--</form>-->


<!-- 引入jQuery文件 -->
<script src="js/jquery-3.4.1.js"></script>
<script>
$("#button").click(function(){
    let id = 5;
	$.ajax({
    	type : "DELETE",
		data : {
			'id' : id,
			'type' : 1
		},
		//url : "http://localhost:8000/blog/10",
		url : "http://localhost/tp6/public/rely/get",
		success : function (res) {
			//console.log(res);
			$('#show').html(res);
		}
    });
});
</script>
</body>
</html>