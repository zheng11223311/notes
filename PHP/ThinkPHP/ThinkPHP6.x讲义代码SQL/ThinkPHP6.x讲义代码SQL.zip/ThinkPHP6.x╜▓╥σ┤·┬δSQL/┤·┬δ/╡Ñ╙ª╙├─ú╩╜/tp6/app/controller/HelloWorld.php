<?php
namespace app\controller;

class HelloWorld
{
    public function index()
    {
        return 'index';
    }
}