<?php /*a:1:{s:33:"C:\wamp\www\tp6\view\show\eq.html";i:1582800673;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>

<?php if($name == 'Mr.Lee'): ?>
    相等
<?php endif; if($name == $name2): ?>
    相等
<?php else: ?>
    不相等
<?php endif; if($name == 'Mr.Lee'): ?>
    相等
<?php endif; $var = '123'; ?>
<?php echo htmlentities($var); define('PI', '3.14'); ?>
<?php echo htmlentities(PI); ?>

原生编码：1.require()；2.engine()；3.php标签

<?php 
    echo 123;
 ?>
echo 123;

</body>
</html>