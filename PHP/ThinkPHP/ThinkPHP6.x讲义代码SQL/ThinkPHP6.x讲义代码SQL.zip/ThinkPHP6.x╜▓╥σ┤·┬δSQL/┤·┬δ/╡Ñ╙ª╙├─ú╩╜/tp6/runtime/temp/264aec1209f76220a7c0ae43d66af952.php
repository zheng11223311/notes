<?php /*a:2:{s:36:"C:\wamp\www\tp6\view\show\block.html";i:1582959334;s:39:"C:\wamp\www\tp6\view\public\layout.html";i:1582959349;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo htmlentities($title); ?></title>
    <meta name="keywords" content="[keywords]">
    <link rel="stylesheet" type="text/css" href="../static/css/basic.css" />
    <script type="text/javascript" src="../static/js/basic.js"></script>
</head>
<body>

header
<nav>nav</nav>

这里主体部分

</body>
</html>