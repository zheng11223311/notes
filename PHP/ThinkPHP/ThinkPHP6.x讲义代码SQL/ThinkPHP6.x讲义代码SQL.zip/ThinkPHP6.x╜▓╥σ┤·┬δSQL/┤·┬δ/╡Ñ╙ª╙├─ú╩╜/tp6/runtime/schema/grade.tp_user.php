<?php 
return array (
  'id' => 'int',
  'username' => 'string',
  'password' => 'string',
  'gender' => 'string',
  'email' => 'string',
  'price' => 'float',
  'details' => 'string',
  'uid' => 'int',
  'status' => 'int',
  'list' => 'string',
  'delete_time' => 'datetime',
  'create_time' => 'datetime',
  'update_time' => 'datetime',
  '_pk' => 'id',
  '_autoinc' => 'id',
);