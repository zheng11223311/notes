<?php /*a:1:{s:28:"C:\wamp\www\tp6\app\404.html";i:1583379423;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>

页面不存在：404！~

</body>
</html>