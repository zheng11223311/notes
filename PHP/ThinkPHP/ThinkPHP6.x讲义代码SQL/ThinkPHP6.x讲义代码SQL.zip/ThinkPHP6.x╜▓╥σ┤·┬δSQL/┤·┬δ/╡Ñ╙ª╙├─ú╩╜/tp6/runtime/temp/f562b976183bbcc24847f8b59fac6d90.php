<?php /*a:1:{s:36:"C:\wamp\www\tp6\view\store\lang.html";i:1583237779;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>

<?php echo htmlentities(lang('require_name')); ?>
<?php echo lang('email_error'); ?>
<?php echo lang('user.login'); ?>

</body>
</html>