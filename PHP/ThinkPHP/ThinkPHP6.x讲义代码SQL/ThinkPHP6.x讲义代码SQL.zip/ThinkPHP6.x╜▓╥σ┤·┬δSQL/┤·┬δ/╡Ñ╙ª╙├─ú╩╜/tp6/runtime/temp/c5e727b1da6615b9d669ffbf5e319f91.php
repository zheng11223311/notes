<?php /*a:3:{s:36:"C:\wamp\www\tp6\view\show\block.html";i:1582959665;s:37:"C:\wamp\www\tp6\view\public\base.html";i:1582959582;s:36:"C:\wamp\www\tp6\view\public\nav.html";i:1582887633;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo htmlentities($title); ?></title>
    <meta name="keywords" content="[keywords]">
    <link rel="stylesheet" type="text/css" href="../static/css/basic.css" />
    <script type="text/javascript" src="../static/js/basic.js"></script>
</head>
<body>

header


    <div>
        这里是主体部分
    </div>


<nav>nav</nav>



</body>
</html>