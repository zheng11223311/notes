<?php 
return array (
  'id' => 'int',
  'user_id' => 'int',
  'role_id' => 'int',
  'details' => 'string',
  '_pk' => 'id',
  '_autoinc' => 'id',
);