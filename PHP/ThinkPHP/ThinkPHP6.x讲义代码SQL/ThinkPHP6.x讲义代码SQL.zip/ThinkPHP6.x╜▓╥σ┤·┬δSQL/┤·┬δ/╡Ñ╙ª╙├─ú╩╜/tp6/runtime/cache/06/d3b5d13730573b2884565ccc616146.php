<?php
//000000000000
 exit();?>
a:1:{i:0;O:22:"think\annotation\Route":14:{s:6:"method";s:3:"GET";s:10:"middleware";N;s:3:"ext";s:4:"html";s:8:"deny_ext";N;s:5:"https";i:0;s:6:"domain";N;s:14:"complete_match";N;s:5:"cache";N;s:4:"ajax";N;s:4:"pjax";N;s:4:"json";N;s:6:"filter";N;s:6:"append";N;s:5:"value";s:6:"ds/:id";}}