<?php 
return array (
  'id' => 'int',
  'user' => 'string',
  'math' => 'int',
  'chinese' => 'int',
  'english' => 'int',
  'create_time' => 'datetime',
  '_pk' => 'id',
  '_autoinc' => 'id',
);