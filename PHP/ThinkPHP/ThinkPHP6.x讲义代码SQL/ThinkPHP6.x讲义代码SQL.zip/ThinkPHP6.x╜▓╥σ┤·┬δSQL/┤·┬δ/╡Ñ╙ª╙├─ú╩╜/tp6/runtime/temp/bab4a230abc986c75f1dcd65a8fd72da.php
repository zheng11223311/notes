<?php /*a:1:{s:35:"C:\wamp\www\tp6\view\code\form.html";i:1583296107;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>

<?php echo captcha_img(); ?>
<!--<img src="<?php echo captcha_src(); ?>" alt="">-->

<form action="../code/check" method="post">
    <input type="text" name="code">
    <input type="submit" value="验证">
</form>

</body>
</html>