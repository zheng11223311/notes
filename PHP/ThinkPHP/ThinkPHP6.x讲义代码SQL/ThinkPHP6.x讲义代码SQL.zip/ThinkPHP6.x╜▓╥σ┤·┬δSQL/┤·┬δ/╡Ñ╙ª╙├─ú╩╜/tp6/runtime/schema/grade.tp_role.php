<?php 
return array (
  'id' => 'int',
  'type' => 'string',
  '_pk' => 'id',
  '_autoinc' => 'id',
);