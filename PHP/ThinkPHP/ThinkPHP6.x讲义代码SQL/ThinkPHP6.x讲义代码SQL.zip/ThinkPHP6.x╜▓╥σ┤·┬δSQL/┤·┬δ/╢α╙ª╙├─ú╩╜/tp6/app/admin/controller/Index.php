<?php
namespace app\admin\controller;

class Index
{
    public function index()
    {
        return '后台首页！';
    }
}