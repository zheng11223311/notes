<?php
\think\facade\Route::rule('ar/:id', 'Address/read');