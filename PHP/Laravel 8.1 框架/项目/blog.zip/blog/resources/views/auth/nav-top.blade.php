<div class="text-center">
    <a href="{{route('login')}}" class="fs-20 font-weight-bold {{$nav=='login'?'text-blue':'text-dark'}} ">登录</a>
    <span> . </span>
    <a href="{{route('register')}}" class="fs-20 font-weight-bold {{$nav=='register'?'text-blue':'text-dark'}} ">注册</a>
</div>