{{-- php 的 asset() 指向public --}}
<link rel="stylesheet" href="{{asset('css/bootstrap.min.css')}}">
<link rel="stylesheet" href="{{asset('css/common.css')}}">
@yield('style')