<div class="text-center">
    <a href="/login" class="fs-20 font-weight-bold {{$nav=='login'?'text-blue':'text-dark'}} ">登录</a>
    <span> . </span>
    <a href="/register" class="fs-20 font-weight-bold {{$nav=='register'?'text-blue':'text-dark'}} ">注册</a>
</div>