

<?php $__env->startSection('title', '修改头像'); ?>

<?php $__env->startSection('style'); ?>
    <style>

    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <div class="row">
            <div class="col-sm-3">
                <?php echo $__env->make('common.user-menu',['nav'=>'avatar'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="col-sm-9 p-0">
                <div class="card">
                    <div class="card-header bg-white fs-14">
                        修改头像
                    </div>
                    <?php echo $__env->make('common.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('common.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="card-body">
                        <form method="post" action="<?php echo e(route('user.avatar.update')); ?>" enctype="multipart/form-data" class="col-md-6 offset-3">
                            <?php echo method_field('put'); ?>
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="exampleFormControlFile1" class="fs-14 font-weight-bold">请选择头像上传</label>
                                <input type="file" name="avatar" class="form-control form-control-sm" id="exampleFormControlFile1"  />
                            </div>
                            <button type="submit" class="btn btn-primary w-25 offset-4">修改</button>
                            
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\学习\wanye\PHP\Laravel 8.1 框架\项目\blog\resources\views/user/avatar.blade.php ENDPATH**/ ?>