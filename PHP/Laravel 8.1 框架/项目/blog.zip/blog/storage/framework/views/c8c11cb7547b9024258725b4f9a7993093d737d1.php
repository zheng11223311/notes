<header class="header">
    <div class="container bg-light d-flex justify-content-between align-items-center">
        <div class="d-flex">
            <a class="logo" href="<?php echo e(route('index')); ?>">Laravel</a>
            
            <form action="<?php echo e(route('index')); ?>" class="form-inline my-2 my-lg-0 ml-3">
                <input name="keyword" value="<?php echo e(request()->query('keyword')); ?>" class="form-control form-control-sm" type="search" placeholder="搜索" />
                <select name="category_id"  type="password" class="form-control form-control-sm ml-2">
                    <option value="0">请选择分类</option>
                    <?php $__currentLoopData = categories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id=>$name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php echo e(request()->query('category_id')==$id?'selected':''); ?> value="<?php echo e($id); ?>"><?php echo e($name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button class="btn btn-sm btn-outline-success ml-2 " type="submit">搜索</button>
            </form>
        </div>
        <div class="right-bth">
            <?php if(auth()->guard()->check()): ?>
                
                <a href="<?php echo e(route('user.info')); ?>" class="text-dark mr-3 text-decoration-none">
                    
                    <img width="30" height="30"
                        src="<?php echo e(auth()->user()->avatar ? asset('storage/' . auth()->user()->avatar) : 'https://t7.baidu.com/it/u=1595072465,3644073269&fm=193&f=GIF'); ?>"
                        alt="" class="rounded-pill">
                    <span><?php echo e(auth()->user()->name); ?></span>
                </a>
                <a href="<?php echo e(route('blog.create')); ?>" class="text-dark mr-3 text-decoration-none">
                    
                   发布博客
                </a>
                <form method="post" action="<?php echo e(route('logout')); ?>" class="d-inline" id="logout">
                    <?php echo csrf_field(); ?>
                    <a href="javascript:;" onclick="document.getElementById('logout').submit()"
                        class="text-dark text-decoration-none">退出</a>
                </form>
            <?php else: ?>
                

                <a href="<?php echo e(route('login')); ?>" class="btn  btn-sm btn-primary">登入</a>
                <a href="<?php echo e(route('register')); ?>" class="btn  btn-sm btn-outline-success ml-2">注册</a>
            <?php endif; ?>
        </div>
    </div>
</header>
<?php /**PATH D:\学习\wanye\PHP\Laravel 8.1 框架\项目\blog\resources\views/layouts/header.blade.php ENDPATH**/ ?>