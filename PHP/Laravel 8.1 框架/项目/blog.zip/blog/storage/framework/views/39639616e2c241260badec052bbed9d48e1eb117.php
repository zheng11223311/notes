<div class="text-center">
    <a href="<?php echo e(route('login')); ?>" class="fs-20 font-weight-bold <?php echo e($nav=='login'?'text-blue':'text-dark'); ?> ">登录</a>
    <span> . </span>
    <a href="<?php echo e(route('register')); ?>" class="fs-20 font-weight-bold <?php echo e($nav=='register'?'text-blue':'text-dark'); ?> ">注册</a>
</div><?php /**PATH D:\学习\wanye\PHP\Laravel 8.1 框架\项目\blog\resources\views/auth/nav-top.blade.php ENDPATH**/ ?>