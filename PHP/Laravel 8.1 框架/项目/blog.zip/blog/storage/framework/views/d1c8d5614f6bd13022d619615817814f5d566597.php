

<?php $__env->startSection('title', '所有博客'); ?>

<?php $__env->startSection('style'); ?>
    <style>

    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <div class="row">
            <div class="col-sm-3">
                <?php echo $__env->make('common.user-menu', ['nav' => 'blog'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="col-sm-9 p-0">
                <div class="card">
                    <div class="card-header bg-white fs-14">
                        所有博客
                    </div>
                    <div class="card-body">
                        <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="del-blog-parent blog-list border-bottom pb-3 mb-3">
                                <div class=""><a href="<?php echo e(route('blog.show',$blog)); ?>" class="text-dark text-decoration-none"><?php echo e($blog->title); ?></a></div>
                                <div class="mt-2 d-flex justify-content-between">
                                    <div class="fs-14 text-muted">
                                        <span>时间 : <?php echo e($blog->updated_at->diffForHumans()); ?></span>
                                        <span>&nbsp;&nbsp; 浏览次数 : <?php echo e($blog->view); ?></span>
                                        <span> &nbsp;&nbsp;评论数 : <?php echo e($blog->comments_count); ?></span>
                                    </div>
                                    <div class="d-flex justify-content-end ">
                                        <div class="custom-control custom-switch mr-3">
                                            <input <?php echo e($blog->status==1?'checked':''); ?> data-url="<?php echo e(route('blog.status',$blog)); ?>" type="checkbox" class="status-blog custom-control-input" id="status-<?php echo e($blog->id); ?>">
                                            <label class="custom-control-label text-muted " style="font-size: 14px" for="status-<?php echo e($blog->id); ?>">是否发布</label>
                                          </div>
                                        <a href="<?php echo e(route('blog.edit',$blog)); ?>" class="btn btn-sm py-0 px-3 btn-primary">编辑</a>
                                        <a href="javascript:;" data-url="<?php echo e(route('blog.destroy',$blog)); ?>" class="del-blog btn btn-sm py-0 px-3 btn-danger ml-2">删除</a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        <?php echo e($blogs->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $(function(){
            /**
             * 删除博客
             * 
            */
           $('.del-blog').click(function(){
            //    console.log($(this));
               $.ajax({
                   url:$(this).data('url'),
                   type:'delete',
                   data:{},
                   dataType:'json',
                   success:(res)=>{
                    // console.log(res);
                    if(res.code==200){
                        // 使用提示
                        alert(res.msg)
                        // 让删除的这条从页面消失
                        // $(this).parent().parent().parent().hidden() 
                        // parents 多父级
                        $(this).parents('.del-blog-parent').remove()
                    }else{
                        alert(res.msg)
                    }
                   }
               })
           })

           /*
           *改变博客状态
           */
          $('.status-blog').change(function(){
            $.ajax({
                   url:$(this).data('url'),
                   type:'patch',
                   data:{},
                   dataType:'json',
                   success:(res)=>{
                    // console.log(res);
                    if(res.code==200){
                        // 使用提示
                        alert(res.msg)
                    }else{
                        alert(res.msg)
                    }
                   }
               })
          })

        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\学习\wanye\PHP\Laravel 8.1 框架\项目\blog\resources\views/user/blog.blade.php ENDPATH**/ ?>