<footer class="footer">
    <div class="blue">
        <div class="container text-white">终身学习</div>
    </div>
    <div class="des">
        网站由 Luwnto 完成,基于PHP 框架Laravel 和CSS 框架 Bootstrap4 开发
    </div>
</footer><?php /**PATH D:\学习\wanye\PHP\Laravel 8.1 框架\项目\blog\resources\views/layouts/footer.blade.php ENDPATH**/ ?>