<!-- Stored in resources/views/child.blade.php -->




<?php $__env->startSection('title', 'Page Title'); ?>


<?php $__env->startSection('sidebar'); ?>
    
    <?php echo \Illuminate\View\Factory::parentPlaceholder('sidebar'); ?>

    <p>这是子模板的内容.</p>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <p>This is my body content.</p>
<?php $__env->stopSection(); ?>


<?php echo e($name); ?>





<?php echo e(time()); ?>

<?php echo e($script); ?>


<?php echo e($html); ?>



<?php echo $html; ?>






{{ $script }}


<script>
    
     
    var json = <?php echo json_encode($json, 15, 512) ?>;
    console.log(json);
</script>




<?php if(count($json) === 1): ?>
    I have one record!
<?php elseif(count($json) > 1): ?>
    I have multiple records!
<?php else: ?>
    I don't have any records!
<?php endif; ?>


<?php if (! (Auth::check())): ?>
    You are not signed in.
<?php endif; ?>


<?php if(auth()->guard()->check()): ?> 
    用户已经通过认证……
<?php else: ?>
    没有登入
<?php endif; ?>

<?php if(auth()->guard()->guest()): ?>
    用户没有通过认证……
<?php endif; ?>




<?php $__currentLoopData = $json; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($loop->first): ?>
        第一次迭代
    <?php endif; ?>

    <?php if($loop->last): ?>
        最后一次迭代
    <?php endif; ?>

    <p>This is user <?php echo e($value); ?></p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<!-- html 注释会被渲染到界面中,f12 可以查看到-->

<?php
    echo '执行原生php 代码';
    $a ='哈哈哈哈';
?>


<?php echo e($a); ?>




<?php echo csrf_field(); ?>


<?php echo $__env->make('list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\学习\wanye\PHP\Laravel 8.1 框架\项目\blog\resources\views/child.blade.php ENDPATH**/ ?>