<style>
    .left-card>h5{
        font-size: 1.15rem !important;
        font-weight: 600;
    }
    .left-card>p{
        font-size: 14px;
        margin-top: 20px;
    }
    .left-card>button{
        color: #3273dc;
        border-color: #3273dc;
    }
    .left-card>button:hover{
        color: white;
        background: #3273dc;
    }
</style>
<div class="card">
    <img src="<?php echo e($imgUrl); ?>" class="card-img-top" alt="..." srcset="">
    <div class="card-body left-card">
        <h5 class="card-title text-center"><?php echo e($title); ?></h5>
        <p class="card-text"><?php echo e($content); ?></p>
        <hr>
        <?php if(isset($category_id)&&!empty($category_id)): ?>
            <a  href="<?php echo e(route('index',['category_id'=>$category_id])); ?>" class="btn btn-outline-primary btn-sm w-100">文章数量<?php echo e($count); ?></a>
        <?php else: ?>
        <button style="cursor: initial" class="btn btn-outline-primary btn-sm w-100">文章数量<?php echo e($count); ?></button>
        <?php endif; ?>
    </div>
</div><?php /**PATH D:\学习\wanye\PHP\Laravel 8.1 框架\项目\blog\resources\views/common/right-card.blade.php ENDPATH**/ ?>