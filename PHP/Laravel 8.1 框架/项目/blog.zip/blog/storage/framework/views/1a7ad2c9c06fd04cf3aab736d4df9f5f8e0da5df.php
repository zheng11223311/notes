
<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/common.css')); ?>">
<?php echo $__env->yieldContent('style'); ?><?php /**PATH D:\学习\wanye\PHP\Laravel 8.1 框架\项目\blog\resources\views/layouts/style.blade.php ENDPATH**/ ?>