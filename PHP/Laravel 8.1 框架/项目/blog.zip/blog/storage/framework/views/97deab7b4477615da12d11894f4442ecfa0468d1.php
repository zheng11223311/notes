

<?php $__env->startSection('title', '编辑博客'); ?>

<?php $__env->startSection('style'); ?>
    <style>

    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container ">
        <div class="card mb-3 mt-4">
            <div class="card-body">
                <form action="">
                    <div class="form-group">
                        <label for="exampleFormControlInput1"> 标题</label>
                        <input type="text" class="form-control" value="第一个博客" id="exampleFormControlInput1"/>
                    </div>
                    <div class="form-group">
                        <label for="exampleFormControlSelect1"> 分类</label>
                        
                        <select class="form-control" id="exampleFormControlSelect1">
                            <option value="0">请选择分类</option>
                            <?php $__currentLoopData = categories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id=>$name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($id); ?>" ><?php echo e($name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="exampleForControlTexteare1">内容</label>
                        <textarea class="form-control" id="exampleForControlTexteare1"></textarea>
                    </div>
                    <button class="btn btn-primary w-25 offset-4">修改</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\学习\wanye\PHP\Laravel 8.1 框架\项目\blog\resources\views/blog/edit.blade.php ENDPATH**/ ?>