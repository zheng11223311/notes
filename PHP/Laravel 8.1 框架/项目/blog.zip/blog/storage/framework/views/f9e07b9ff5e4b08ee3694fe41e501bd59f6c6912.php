

<?php $__env->startSection('title','首页'); ?>


<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/index.css')); ?>">
    <style>

    </style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="jumbotron jumbotron-fluid px-0">
        <div class="container text-center text-white">
            <h4 class="display-6">基于Laravel 的博客项目</h4>
            <p class="lead">项目仅用于学习</p>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-sm-9">
                <div class="card">
                    <div class="card-body">
                        
                       <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="article-body">
                                <div>
                                    
                                    <span class="article-author"><?php echo e($blog->user->name); ?></span>
                                    
                                    
                                    
                                    <span class="article-time"><?php echo e($blog->updated_at->diffForHumans()); ?></span>
                                </div>
                                <h2 class="font-weight-bold my-3 article-title">
                                    
                                    <a class="text-dark" href="<?php echo e(route('blog.show',$blog->id)); ?>"><?php echo e($blog->title); ?></a>
                                </h2>
                                <div class="article-des"><?php echo e($blog->content); ?></div>
                                <div>
                                    
                                    
                                    <a href="#" class="badge badge-warning mt-3 article"><?php echo e(getCategories()[$blog->category_id]); ?></a>
                                </div>
                            </div>
                            <hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        
                        
                        
                        
                        
                        
                        <?php echo e($blogs->withQueryString()->links()); ?>

                        
                        
                        
                        
                        
                    </div>
                </div>
            </div>
            <div class="col-sm-3 p-0">
                <?php echo $__env->make('common.right-card',[
                    'imgUrl'=>'https://www4.bing.com//th?id=OHR.SwedishAntenna_ZH-CN9163420082_1920x1080.jpg&rf=LaDigue_1920x1080.jpg&pid=hp&w=240&h=135',
                    'title'=>'博客网站',
                    'content'=>'一个用来学习Laravel 的博客项目,基于Bootstrap4.0 开发',
                    // 'count'=>$blogs->count()     //当前页的数量
                    'count'=>$blogs->total()     //总数量
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\学习\wanye\PHP\Laravel 8.1 框架\项目\blog\resources\views/index/index.blade.php ENDPATH**/ ?>