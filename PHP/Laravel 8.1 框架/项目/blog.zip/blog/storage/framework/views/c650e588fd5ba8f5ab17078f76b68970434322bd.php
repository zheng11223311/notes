
<p>list.....</p>
<p>list.....</p>
<p>list.....</p>
<p>list.....</p>
<p>list.....</p>
<p>list.....</p><?php /**PATH D:\学习\wanye\PHP\Laravel 8.1 框架\项目\blog\resources\views/list.blade.php ENDPATH**/ ?>