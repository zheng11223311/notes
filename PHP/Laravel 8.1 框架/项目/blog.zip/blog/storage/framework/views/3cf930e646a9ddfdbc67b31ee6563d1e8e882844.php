<script src="<?php echo e(asset('js/jquery-3.6.0.min.js')); ?>"></script>
<script src="https://unpkg.com/@popperjs/core@2"></script>

<script>
    // ajax 全局设置
    $.ajaxSetup({
        // 获取头部的安全认证信息,为headers 添加认证
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});
</script>


<?php echo $__env->yieldContent('script'); ?><?php /**PATH D:\学习\wanye\PHP\Laravel 8.1 框架\项目\blog\resources\views/layouts/script.blade.php ENDPATH**/ ?>