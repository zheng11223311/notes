<div class="card">
    <ul class="list-group list-group-flush text-center">
        <li class="list-group-item <?php echo e($nav=='info'?'bg-primary':''); ?>">
            
            
            <a href="<?php echo e(route('user.info')); ?>" class="<?php echo e($nav=='info'?'text-white':''); ?>">个人信息</a>
        </li>
        <li class="list-group-item <?php echo e($nav=='avatar'?'bg-primary':''); ?>">
            <a href="/user/avatar" class="<?php echo e($nav=='avatar'?'text-white':''); ?>">修改头像</a>
        </li>
        <li class="list-group-item <?php echo e($nav=='blog'?'bg-primary':''); ?>">
            <a href="/user/blog" class="<?php echo e($nav=='blog'?'text-white':''); ?>">所有博客</a>
        </li>
    </ul>
</div><?php /**PATH D:\学习\wanye\PHP\Laravel 8.1 框架\项目\blog\resources\views/common/user-menu.blade.php ENDPATH**/ ?>