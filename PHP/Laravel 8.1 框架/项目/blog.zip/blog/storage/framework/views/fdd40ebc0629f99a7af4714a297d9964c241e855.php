

<?php $__env->startSection('title', '发布博客'); ?>

<?php $__env->startSection('style'); ?>
    <style>

    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container ">
        <div class="card mb-3 mt-4">
            <div class="card-body">
                <form action="<?php echo e(route('blog.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo $__env->make('common.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('common.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="form-group">
                        <label for="exampleForControlInput1">标题</label>
                        
                        <input name="title" value="<?php echo e(old('title')); ?>" type="text" class="form-control" id="exampleForControlInput1"/>
                    </div>
                    <div class="form-group">
                        <label for="exampleForControlSelect1">分类</label>
                        <select name="category_id" value="" type="password" class="form-control" id="exampleForControlSelect1">
                            <option value="0">请选择分类</option>
                            <?php $__currentLoopData = categories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id=>$name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php echo e(old('category_id')==$id?'selected':''); ?> value="<?php echo e($id); ?>"><?php echo e($name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="exampleForControlTexteare1">内容</label>
                        
                        <textarea name="content"  class="form-control" id="exampleForControlTexteare1"><?php echo e(old('content')); ?></textarea>
                    </div>
                    <button class="btn btn-primary w-25 offset-4">发布</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\学习\wanye\PHP\Laravel 8.1 框架\项目\blog\resources\views/blog/create.blade.php ENDPATH**/ ?>