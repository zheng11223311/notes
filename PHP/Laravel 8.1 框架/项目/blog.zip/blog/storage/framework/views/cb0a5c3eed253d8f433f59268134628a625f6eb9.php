<?php $__env->startSection('title','注册'); ?>

<?php $__env->startSection('style'); ?>
<style>

</style>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row pt-4">
            <div class="card col-lg-4 offset-4 mb-3 mt-5">
                <div class="card-body">

                    <?php echo $__env->make('auth.nav-top',['nav'=>'register'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <hr>
                    <?php echo $__env->make('common.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <form method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="exampleInputName" class="fs-14 font-weight-bold">用户名</label>
                            <input type="text" 
                            id="exampleInputName"
                            name="name"
                            placeholder="请填写用户名或邮箱"
                            aria-describedby="emailHelp"
                            value="<?php echo e(old('name')); ?>"
                            class="form-control form-control-sm">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputName1" class="fs-14 font-weight-bold">邮箱</label>
                            <input type="email" 
                            id="exampleInputName1"
                            name="email"
                            placeholder="请填写邮箱"
                            value="<?php echo e(old('email')); ?>"
                            aria-describedby="emailHelp"
                            class="form-control form-control-sm">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1" class="fs-14 font-weight-bold">密码</label>
                            <input type="password" 
                            id="exampleInputPassword1"
                            placeholder="请输入密码"
                            name="password"
                            class="form-control form-control-sm">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword2" class="fs-14 font-weight-bold">确认密码</label>
                            <input type="password" 
                            id="exampleInputPassword2"
                            placeholder="再次输入密码"
                            name="password_confirmation"
                            class="form-control form-control-sm">
                        </div>
                        <button class="btn btn-primary btn-sm w-100 mt-4 ">登录</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\学习\wanye\PHP\Laravel 8.1 框架\项目\blog\resources\views/auth/register.blade.php ENDPATH**/ ?>