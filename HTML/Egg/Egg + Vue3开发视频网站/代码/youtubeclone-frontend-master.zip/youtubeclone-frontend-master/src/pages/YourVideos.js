import React from "react";
import Channel from "./Channel";

const YourVideos = () => <Channel />;

export default YourVideos;
