
// import 'dart:io';
import "dart:math";
main(){
 
    print(min(12,23));

    print(max(12,25));
    
}