void main(){

 
//  1、基础赋值运算符   =   ??=      


        // int a=10;
        // int b=3;
        // print(a);
        // int c=a+b;   //从右向左


    // b??=23;  表示如果b为空的话把 23赋值给b
        
        // int b=6;
        // b??=23;
        // print(b);

      
        // int b;
        // b??=23;
        // print(b);


//2、  复合赋值运算符   +=  -=  *=   /=   %=  ~/=

  
    // var a=12;
    // a=a+10;
    // print(a);



    // var a=13;
    // a+=10;   //表示a=a+10
    // print(a);





   var a=4;
   a*=3;  //a=a*3;
   print(a);


}