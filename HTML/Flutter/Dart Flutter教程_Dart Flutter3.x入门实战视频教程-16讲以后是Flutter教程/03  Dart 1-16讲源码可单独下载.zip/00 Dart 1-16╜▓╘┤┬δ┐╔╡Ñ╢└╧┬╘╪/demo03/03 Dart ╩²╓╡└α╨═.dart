/*
Dart数据类型：数值类型

    int 

    double
*/



void main(){

  //1、int   必须是整型


    int a=123;
    a=45;
    print(a);


  //2、double  既可以是整型 也可是浮点型

    double b=23.5;
    b=24;
    print(b);

  //3、运算符

    // + - * / %
    
    var c=a+b;
    print(c);


}

