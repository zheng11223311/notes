/*
Dart判断数据类型    

is 关键词来判断类型
*/

void main(){

  

  // var str='1234';
  // if(str is String){
  //   print('是string类型');
  // }else if(str is int){
  //    print('int');
  // }else{
  //    print('其他类型');
  // }


  
  var str=123;
  if(str is String){
    print('是string类型');
  }else if(str is int){
     print('int');
  }else{
     print('其他类型');
  }



}

