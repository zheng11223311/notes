/*

Dart 变量：

  dart是一个强大的脚本类语言，可以不预先定义变量类型 ，自动会类型推倒

  dart中定义变量可以通过var关键字可以通过类型来申明变量

  如：
    var str='this is var';

    String str='this is var';

    int str=123;

  注意： var 后就不要写类型 ，  写了类型 不要var   两者都写   var  a int  = 5;  报错

*/

void main(){
   
    // var str='你好dart';
    // var myNum=1234;
    // print(str);
    // print(myNum);


    //字符串
    // String str='你好dart';
    // print(str);


    //数字类型
    // int myNum=12354; 
    // print(myNum);




    //dart里面有类型校验

    // var str='';
    // str=1234;
    // print(str);


      String str="2131242";
      print(str);

      int myNum=1243214;
      print(myNum);


}