package com.example.flutter05

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
