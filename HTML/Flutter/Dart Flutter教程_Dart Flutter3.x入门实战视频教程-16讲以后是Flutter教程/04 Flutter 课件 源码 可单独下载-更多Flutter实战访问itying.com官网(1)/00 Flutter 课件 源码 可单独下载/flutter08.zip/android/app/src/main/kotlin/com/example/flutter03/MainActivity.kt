package com.example.flutter03

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
