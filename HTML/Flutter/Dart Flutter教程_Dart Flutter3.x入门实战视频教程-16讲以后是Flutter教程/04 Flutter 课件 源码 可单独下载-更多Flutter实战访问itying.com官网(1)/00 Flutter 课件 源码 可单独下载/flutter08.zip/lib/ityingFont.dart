import 'package:flutter/material.dart';

class ItyingIcon{
  static const IconData book=IconData(
    0x3447,
    fontFamily:"ityingIcon",
    matchTextDirection:true
  );
  static const IconData weixin=IconData(
    0xf0106,
    fontFamily:"ityingIcon",
    matchTextDirection:true
  );
  static const IconData cart=IconData(
      0xf0179,
      fontFamily:"ityingIcon",
      matchTextDirection:true
   );
   static const IconData yonghu=IconData(
      0xe633,
      fontFamily:"flutterIcon",
      matchTextDirection:true
   );
    static const IconData address=IconData(
      0xe64e,
      fontFamily:"flutterIcon",
      matchTextDirection:true
   );

    static const IconData category=IconData(
      0xe71b,
      fontFamily:"flutterIcon",
      matchTextDirection:true
   );

   
}

