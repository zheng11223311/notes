package com.example.flutter29

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
