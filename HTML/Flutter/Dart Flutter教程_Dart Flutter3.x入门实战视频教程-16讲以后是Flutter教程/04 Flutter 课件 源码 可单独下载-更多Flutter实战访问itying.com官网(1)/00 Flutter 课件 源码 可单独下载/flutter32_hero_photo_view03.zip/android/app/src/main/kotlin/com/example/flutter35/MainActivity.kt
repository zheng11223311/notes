package com.example.flutter35

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
