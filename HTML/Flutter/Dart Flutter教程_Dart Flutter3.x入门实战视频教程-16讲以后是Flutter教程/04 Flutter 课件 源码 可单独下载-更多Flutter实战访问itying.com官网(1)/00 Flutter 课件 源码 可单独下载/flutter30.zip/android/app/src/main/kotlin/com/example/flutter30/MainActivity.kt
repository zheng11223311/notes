package com.example.flutter30

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
