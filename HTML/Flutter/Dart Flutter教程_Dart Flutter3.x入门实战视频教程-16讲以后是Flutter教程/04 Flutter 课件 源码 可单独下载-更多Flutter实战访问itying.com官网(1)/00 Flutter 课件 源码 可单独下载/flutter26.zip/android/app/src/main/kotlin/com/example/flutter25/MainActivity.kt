package com.example.flutter25

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
