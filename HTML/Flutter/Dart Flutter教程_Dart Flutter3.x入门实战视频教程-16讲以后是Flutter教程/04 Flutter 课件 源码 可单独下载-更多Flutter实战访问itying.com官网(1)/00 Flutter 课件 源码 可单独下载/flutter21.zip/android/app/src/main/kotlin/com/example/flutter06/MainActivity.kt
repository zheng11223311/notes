package com.example.flutter06

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
