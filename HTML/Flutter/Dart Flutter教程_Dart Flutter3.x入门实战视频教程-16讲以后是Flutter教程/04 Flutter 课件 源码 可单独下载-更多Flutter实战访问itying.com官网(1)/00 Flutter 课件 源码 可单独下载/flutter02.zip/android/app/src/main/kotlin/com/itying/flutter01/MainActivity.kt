package com.itying.flutter01

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
