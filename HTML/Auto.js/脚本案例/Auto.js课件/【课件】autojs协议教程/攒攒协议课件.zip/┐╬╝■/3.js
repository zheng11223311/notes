var awemeId = "6857444718016564494";
app.startActivity({ 
    action: "android.intent.action.VIEW", 
    data:"snssdk1128://aweme/detail/" + awemeId, 
    packageName: "com.ss.android.ugc.aweme", 
});

