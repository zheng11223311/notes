/**
 * 悟空造世
 * 
 * QQ交流群：4607221
 * 阅者须知：目前特征库是针对快手的滑块开发的，码了个思路，有能力可以自己制作其他滑块的特征库，或者按思路自己编写。
 * 开发时间：2020-7-15 
 * 测试设备：小米6x、小米8、小米4
 * 安卓版本：10、9、6.1；
 * Auto.j版本：pro 8.05
 */

ibrary = require("library");//载入模块

if (!requestScreenCapture()) {
    toast("请求截图失败");
}

sleep(500)
orcImg()
function orcImg() {
    img = images.captureScreen();
    let x = take(img)
    //x为当前返回的缺口坐标。默认返回缺口左边缘的x坐标，极少情况会返回偏中间的，当然，还有极少情况识别不到的。建议直接写刷新的点击刷新后重新识别即可。
    log("当前缺口的x坐标为：" + x)
    //这里写滑动代码
}


//主特征数组化
function arrayTz(arrTz, mike) {
    for (let i = 0; i < arrTz.length; i++) {
        if (i > 1) {
            let getarr = arrTz[i].split("|");
            mike[i - 2] = [getarr[0], getarr[1], getarr[2]]
        }
    }
    return mike
}

//副特征数组化
function arrayKz(arrTz, mike) {
    for (let indx = 0; indx < arrTz.length; indx++) {
        let scpOne = arrTz[indx].split(",")[0].split("|");
        let scpTwo = arrTz[indx].split(",")[1].split("|");
        mike.push([scpOne[0], scpOne[1], scpOne[2]]);
        mike.push([scpTwo[0], scpTwo[1], scpTwo[2]]);
    }
    return mike;
}

function take(img) {
    seek = (weik, im) => {
        p = images.findMultiColors(im, "#000000", weik, {
            "region": [440, 387, 449, 444],//定义找色区域mkk
        });
        return p ? p.x : false;
    }
    period = (im) => {
        for (let k in ibrary.KS) {
            let seeker = seek(arrayTz(ibrary.KS[k], []), im);
            if (seeker) {
                switch (ibrary.KS[k][0]) {
                    case "左上角特征":
                        log("识别到:" + ibrary.KS[k][0])
                        if (arrayKz(ibrary.LeftTopRightOne, []) || arrayKz(ibrary.TopLeftLeft, [])) return seeker;
                        break;
                    case "左下角特征":
                        log("识别到:" + ibrary.KS[k][0]);
                        if (arrayKz(ibrary.bottomLeftLeft, []) || arrayKz(ibrary.LeftTopRightTwo, [])) return seeker;
                        break;
                    case "右上角特征":
                        log("识别到:" + ibrary.KS[k][0]);
                        if (arrayKz(ibrary.rightTop, []) && arrayKz(ibrary.TopRightLeft, []) && arrayKz(ibrary.TopLeftLeft, [])) return seeker;
                        break;
                    case "右下角特征":
                        log("识别到:" + ibrary.KS[k][0]);
                        if (arrayKz(ibrary.bottomRihtLeft, []) || arrayKz(ibrary.rigthBottom, [])) return seeker;
                        break;
                    case "四边框框特征":
                        log("识别到:" + ibrary.KS[k][0]);
                        break;
                }
                console.log("本次未识别到");
            }
        }
        return false;
    }
    mike = (img, i) => {
        var g = images.grayscale(img);
        var result = images.threshold(g, i, 255);
        result.saveTo("/sdcard/脚本/二值化.jpg");//不本地的情况下貌似报错，具体自测
        var im = images.read("/sdcard/脚本/二值化.jpg")
        let ik = period(im);
        g.recycle();
        return ik ? ik : false;
    };
    for (let i = 80; i <= 140; i++) {
        log("循环第：" + i)
        let mkk = mike(img, i);
        if (mkk) return mkk
    }
    return console.log("未识别到缺口");
}