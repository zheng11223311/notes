

var library = {};
methodTapBottom = function (careful, arrY, y) {
    for (let indx = 0; indx < 35; indx++) {
        let arr = arrY[0] + "|" + (y + indx) + "|" + library.variable[0] + "," + arrY[1] + "|" + (y + indx) + "|" + library.variable[1]
        careful.push(arr);
    }
    return careful;
}
TopRightLeft = function (careful, arrY, x) {
    for (let indx = 0; indx < 35; indx++) {
        let arr = (x - indx) + "|" + arrY[0] + "|" + library.variable[0] + "," + (x - indx) + "|" + arrY[1] + "|" + library.variable[1]
        careful.push(arr);
    }
    return careful;
}
//快手滑块主特征库
library.KS = {
    '主特征1': ["左上角特征", "686,446", "12|-3|#ffffff", "13|0|#000000", "20|-3|#ffffff", "23|0|#000000", "30|-3|#ffffff", "31|1|#000000", "14|12|#000000", "-3|6|#ffffff", "0|9|#000000", "-3|42|#ffffff", "1|41|#000000", "-3|32|#ffffff", "0|29|#000000", "-3|22|#ffffff", "0|17|#000000", "12|9|#000000", "17|34|#000000", "8|45|#ffffff"],
    '主特征2': ["左下角特征", "686,446", "0|14|#000000", "-4|120|#ffffff", "0|122|#000000", "1|128|#ffffff", "6|122|#000000", "7|127|#ffffff", "-3|108|#ffffff", "2|108|#000000", "6|77|#ffffff", "19|106|#000000", "16|100|#000000", "9|107|#000000", "31|92|#000000", "27|81|#000000", "24|73|#ffffff", "11|76|#ffffff", "7|76|#ffffff", "0|81|#000000"],
    '主特征3': ["右上角特征", "686,446", "2|3|#000000", "2|36|#000000", "102|-5|#ffffff", "102|0|#000000", "114|2|#000000", "116|-4|#ffffff", "123|4|#000000", "130|4|#ffffff", "129|-6|#ffffff", "118|9|#000000", "112|12|#000000", "103|16|#000000", "98|17|#000000", "119|-5|#ffffff", "129|24|#ffffff", "118|28|#000000", "117|17|#000000", "65|18|#000000", "45|18|#000000"],
    '主特征4': ["右下角特征", "686,446", "122|120|#000000", "130|129|#ffffff", "116|122|#000000", "116|128|#ffffff", "104|122|#000000", "102|129|#ffffff", "123|115|#000000", "132|115|#ffffff", "112|111|#000000", "130|89|#ffffff", "122|87|#000000", "115|98|#000000", "130|100|#ffffff", "98|89|#000000", "87|76|#000000", "73|100|#000000", "88|112|#000000", "129|111|#ffffff"],
    '主特征5': ["四边框特征", "686,446", "1|124|#000000", "-2|127|#ffffff", "126|124|#000000", "128|126|#ffffff", "126|-1|#000000", "129|-3|#ffffff", "-3|-2|#ffffff", "126|25|#000000", "129|27|#ffffff", "129|29|#ffffff", "126|34|#000000", "129|87|#ffffff", "125|87|#000000", "128|103|#ffffff", "125|107|#000000", "118|127|#ffffff", "116|124|#000000", "30|128|#ffffff", "20|124|#000000", "12|127|#ffffff"]
}
//快手滑块副特征库
library.variable = ["#000000", "#ffffff"]
library.rightTop = methodTapBottom([], ['127', '128'], 0)//上右垂直边框
library.rigthBottom = methodTapBottom([], ['124', '128'], 83)//下右垂直边框
library.LeftTopRightOne = methodTapBottom([], ['1', '-2',], -1)//左边上垂直边框
library.LeftTopRightTwo = methodTapBottom([], ['1', '-2'], 85)//左边下垂直边框
library.TopRightLeft = TopRightLeft([], ['0', '-3'], 126)//顶部靠右，右到左 边框
library.TopLeftLeft = TopRightLeft([], ['0', '-3'], 40)//顶部靠左，右到左 边框
library.bottomRihtLeft = TopRightLeft([], ['124', '127'], 125)//底部部靠右，右到左 边框
library.bottomLeftLeft = TopRightLeft([], ['124', '127'], 40)//底部部靠左，右到左 边框
module.exports = library;
