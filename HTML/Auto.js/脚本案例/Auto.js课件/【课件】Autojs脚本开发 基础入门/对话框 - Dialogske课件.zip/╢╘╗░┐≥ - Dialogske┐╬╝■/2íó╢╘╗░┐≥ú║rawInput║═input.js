
// "ui";

// toast(rawInput('这是输入框的标题','这是输入框的内容'))


// rawInput('请输入你的年龄','',(age => {

//     toast("你的年龄是："+age)

// }));
// rawInput('请输入你的年龄','18').then(age => {

//     toast("你的年龄是："+age)

// });



dialogs.input('请输入内容','a()')

function a(){
    toast('这是a函数')
}





