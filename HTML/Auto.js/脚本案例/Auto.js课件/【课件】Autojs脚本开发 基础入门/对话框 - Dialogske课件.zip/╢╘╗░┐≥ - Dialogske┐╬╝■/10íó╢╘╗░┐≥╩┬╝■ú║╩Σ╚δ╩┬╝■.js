




dialogs.build({
    title: "请输入",
    positive: "确定",
    negative: "取消",
    inputPrefill: ""
}).on('input_change',function(text,dialog){

    log(text)

}).show()















// toast('阿涛QQ/微信:656206105')