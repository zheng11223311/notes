


var d = dialogs.build({
    title: '进度条演示',
    progress: {
        max: 100
    },
    positive: '确定按钮'

}).show()



sleep(2000)
log(d.getActionButton('positive'))












toast('阿涛QQ/微信:656206105')