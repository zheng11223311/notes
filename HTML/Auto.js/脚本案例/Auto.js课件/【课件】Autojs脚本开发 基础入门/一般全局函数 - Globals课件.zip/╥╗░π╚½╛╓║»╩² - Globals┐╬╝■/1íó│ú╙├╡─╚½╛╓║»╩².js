
//n整数型，毫秒
// sleep(3000)

// toast('123')

// var _toast_ = toast;

// toast = function(message){
//   _toast_(message);
//   sleep(2000);
// }

// for(var i = 0; i < 100; i++){
//   toast(i);
// }

// var a = 123;

// // toast(a)

// log(a)

toastLog('123')

exit()


toast('阿涛QQ/微信：656206105')