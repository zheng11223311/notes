




// setClip('立体空间')

// // log(getClip())
// // paste()

// id('com.tencent.mm:id/al_').findOne().paste()

toast('阿涛QQ/微信：656206105')