


// text('通讯录').waitFor();
// sleep(1000)


// waitForActivity('com.tencent.mm.plugin.sns.ui.SnsTimeLineUI')

// toast('已经到了这个页面')


waitForPackage('com.tencent.mm')


toast('已经到了这个应用')




// toast('阿涛QQ/微信：656206105')