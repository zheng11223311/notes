







// var packageName = currentPackage();

// log(packageName)

var activity = currentActivity()

log(activity)










toast('阿涛QQ/微信：656206105')