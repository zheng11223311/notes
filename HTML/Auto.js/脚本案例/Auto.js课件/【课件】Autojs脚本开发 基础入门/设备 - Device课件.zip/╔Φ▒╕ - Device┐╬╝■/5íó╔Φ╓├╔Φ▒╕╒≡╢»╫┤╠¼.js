


device.vibrate(5000)

sleep(1500)
device.cancelVibration()





toast('阿涛QQ/微信：656206105')