
var b = device.getBrightness()

log(b)

var m = device.getBrightnessMode()

log(m)

device.setBrightness(1200)

device.setBrightnessMode(0)





toast('阿涛QQ/微信：656206105')