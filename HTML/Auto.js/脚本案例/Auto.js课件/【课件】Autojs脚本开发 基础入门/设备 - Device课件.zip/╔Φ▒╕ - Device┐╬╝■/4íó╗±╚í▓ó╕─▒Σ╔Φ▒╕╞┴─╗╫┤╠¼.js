

// var bool = device.isScreenOn()

// log(bool)

// device.wakeUp()

// device.wakeUpIfNeeded()

// device.keepScreenOn()

// device.keepScreenDim()
// device.cancelKeepingAwake()

toast('阿涛QQ/微信：656206105')