


// var m = device.getMusicVolume()

// log(m)


// var n = device.getNotificationVolume()

// log('通知的音量：'+n)


// var a = device.getAlarmVolume()

// log('闹铃的音量：'+a)

// var mx = device.getMusicMaxVolume();

// log(mx)

// var nx = device.getNotificationMaxVolume()
// log(nx)

// var ax = device.getAlarmMaxVolume()
// log(ax)

// try {
//     device.setMusicVolume(10)
// } catch (error) {
//     log('没有权限修改音量')
// }

// device.setNotificationVolume(10)

// device.setAlarmVolume(2)

toast('阿涛QQ/微信：656206105')