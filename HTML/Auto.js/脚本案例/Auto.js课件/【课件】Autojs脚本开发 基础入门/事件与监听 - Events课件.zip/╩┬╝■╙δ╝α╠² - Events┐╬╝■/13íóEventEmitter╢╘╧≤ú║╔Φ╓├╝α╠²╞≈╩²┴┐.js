

events.observeKey();

events.on('key',function(){
    toast("按键被按下");
});
events.on('key',function(){
    toast("按键被按下");
});

events.on('key',function(){
    toast("按键被按下");
});
events.on('key',function(){
    toast("按键被按下");
});
events.on('key',function(){
    toast("按键被按下");
});

events.on('key',function(){
    toast("按键被按下");
});
events.on('key',function(){
    toast("按键被按下");
});
events.on('key',function(){
    toast("按键被按下");
});

events.on('key',function(){
    toast("按键被按下");
});


events.on('key',function(){
    toast("按键被按下");
});



log(events.getMaxListeners())

events.setMaxListeners(11);

events.on('key',function(){
    toast("按键被按下");
});



toast('123')