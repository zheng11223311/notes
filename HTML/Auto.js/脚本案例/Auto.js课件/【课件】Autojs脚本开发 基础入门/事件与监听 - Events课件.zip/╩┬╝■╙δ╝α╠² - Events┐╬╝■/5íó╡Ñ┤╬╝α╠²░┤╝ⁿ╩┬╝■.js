





// 第一步:启用按键监听
events.observeKey();

// events.onceKeyDown('volume_up',function(keyEvent){
//     toast('音量上键被按下')
// })

events.onceKeyUp('volume_up',function(keyEvent){
    toast('音量上键被抬起')
})














toast('阿涛QQ/微信：656206105')