



// 第一步:启用按键监听
events.observeKey();

// events.on('key',function(keyCode,keyEvent){

//     // log(keyEvent.keyCodeToString(keyCode));
    
//     log(keyEvent.getAction())


    
// })

events.on('key_up',function(keyCode,keyEvent){

    log(keyCode)

})












toast('阿涛QQ/微信：656206105')