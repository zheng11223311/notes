


// 监听窗口变化
auto.registerEvent('view_clicked', e => {


    log(e)
    
});

setInterval(() => {},1000)