




var emitter = events.emitter()

log(emitter)





toast("123");