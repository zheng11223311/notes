



events.broadcast.emit('demo','这是传递的参数');










