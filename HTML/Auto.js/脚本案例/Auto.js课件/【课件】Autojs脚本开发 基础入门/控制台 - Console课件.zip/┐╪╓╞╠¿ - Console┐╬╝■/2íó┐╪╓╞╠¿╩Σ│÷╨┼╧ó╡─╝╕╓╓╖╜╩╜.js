
var a = 123;

console.show()

log('测试')

// console.log('测试数据')

// log(a,'测试',a);


// console.trace('123')

console.trace(a)


print('text',a)







toast('阿涛QQ/微信：65620605')