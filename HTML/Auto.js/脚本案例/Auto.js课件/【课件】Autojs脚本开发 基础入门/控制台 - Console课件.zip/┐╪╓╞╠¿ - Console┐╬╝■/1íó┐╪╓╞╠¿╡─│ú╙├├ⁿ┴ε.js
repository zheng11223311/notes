


console.show()


console.log('测试');

sleep(3000)

// console.hide()

console.clear()


sleep(3000)

console.hide()

toast('阿涛QQ/微信：65620605')