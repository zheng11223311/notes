


console.show()

var n = console.input("请输入一个数字:"); 


toast(n + 1);



















toast('阿涛QQ/微信：65620605')