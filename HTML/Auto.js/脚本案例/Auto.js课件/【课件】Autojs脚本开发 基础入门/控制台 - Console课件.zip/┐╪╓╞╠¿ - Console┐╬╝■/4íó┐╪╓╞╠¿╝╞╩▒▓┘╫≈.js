
console.show()

console.time('123')

var arr = ['1','2','3','4','5']
var num = arr.length;

for(var i=0; i < num; i++){
    log(arr[i])
}

console.timeEnd('123')

toast('阿涛QQ/微信：65620605')