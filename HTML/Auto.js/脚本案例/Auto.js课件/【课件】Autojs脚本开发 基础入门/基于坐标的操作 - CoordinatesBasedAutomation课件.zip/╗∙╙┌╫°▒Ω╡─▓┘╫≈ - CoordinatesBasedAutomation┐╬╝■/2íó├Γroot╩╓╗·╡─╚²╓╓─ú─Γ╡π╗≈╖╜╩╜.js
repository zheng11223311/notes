


// click(161,812)


// longClick(161,812)


press(161,812,1500)







toast('阿涛QQ/微信：656206105')