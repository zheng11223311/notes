


var ra = new RootAutomator();

events.on('exit', function(){
  ra.exit();
});


//让"手指2"点击位置(200, 200);
// ra.tap(200, 200, 1);

// ra.longPress(100,500)

// toast('阿涛QQ/微信：656206105')