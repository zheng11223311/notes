




log(device.width)


log(device.height)


click(800,400)

setScreenMetrics(1080, 2340)

click(800,400)



toast('阿涛QQ/微信：656206105')