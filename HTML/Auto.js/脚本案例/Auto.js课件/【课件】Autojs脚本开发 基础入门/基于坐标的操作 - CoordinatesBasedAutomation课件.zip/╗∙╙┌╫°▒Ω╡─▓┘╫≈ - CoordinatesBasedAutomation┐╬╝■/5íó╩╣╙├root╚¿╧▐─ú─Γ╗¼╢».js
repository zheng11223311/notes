


var ra = new RootAutomator();

events.on('exit', function(){
  ra.exit();
});


ra.swipe(100, 500, 500, 500,500,1)














toast('阿涛QQ/微信：656206105')