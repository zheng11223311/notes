



// engines.execScriptFile(path[, config])


engines.execScriptFile('/sdcard/脚本/demo.js',{
    delay: 2000,
    loopTimes: 3,
    interval: 1000
})








// toast('阿涛QQ/vx:656206105')