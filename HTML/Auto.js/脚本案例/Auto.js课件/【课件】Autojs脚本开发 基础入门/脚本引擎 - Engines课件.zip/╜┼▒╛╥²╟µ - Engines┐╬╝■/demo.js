



//监听say事件
events.on("say", function(words){
    toastLog(words);
});

//保持脚本运行
setInterval(()=>{}, 1000);













// toast('我是脚本引擎中的js文件')