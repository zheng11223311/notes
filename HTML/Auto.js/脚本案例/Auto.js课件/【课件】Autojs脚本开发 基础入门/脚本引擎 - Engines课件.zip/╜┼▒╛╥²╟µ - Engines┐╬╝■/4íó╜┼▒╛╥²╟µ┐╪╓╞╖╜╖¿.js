

// engines.stopAll()

engines.execScript('a','sleep(55000)')

sleep(2000)

// engines.stopAllAndToast()

// log(engines.myEngine())

log(engines.all())

sleep(5000)

toast('阿涛QQ/vx:656206105')