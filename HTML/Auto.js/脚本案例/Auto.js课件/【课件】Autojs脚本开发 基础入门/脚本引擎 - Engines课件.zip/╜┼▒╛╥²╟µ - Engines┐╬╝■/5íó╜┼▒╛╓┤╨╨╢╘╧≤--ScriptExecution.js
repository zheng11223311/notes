




var executionObject = engines.execScriptFile('/sdcard/脚本/demo.js');

sleep(1500)

log("这是引擎对象："+executionObject.getEngine())


log("这是引擎配置对象："+executionObject.getConfig())



toast('阿涛QQ/vx:656206105')