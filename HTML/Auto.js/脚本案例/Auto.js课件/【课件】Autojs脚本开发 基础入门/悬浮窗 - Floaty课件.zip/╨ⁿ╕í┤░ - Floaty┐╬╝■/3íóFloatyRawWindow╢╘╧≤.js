


var w = floaty.rawWindow(
    <frame gravity="center">
        <text id="text">悬浮文字</text>
    </frame>
);

w.setSize(-1, -1);
// w.setTouchable(true);

// log(w.getX())
// log(w.getY())

setInterval(()=>{}, 1000);


toast('阿涛QQ656206105')