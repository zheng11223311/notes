

var w = floaty.window(
    <vertical gravity="center">
        <text id="aaa">悬浮文字</text>
        {/* <button>按钮</button> */}
    </vertical>
);

// w.aaa.setText('文本')

// ui.run(function(){

//     w.aaa.setText("aaa");

// });


w.setAdjustEnabled(true)

// w.setPosition(500, 500)

// log(w.getX())
// log(w.getY())

// w.setSize(300, 100)

// setTimeout(()=>{
//     w.close();
// }, 2000);

w.exitOnClose()

setInterval(()=>{}, 1000);


toast('阿涛QQ656206105')