

var storage = storages.create('activation');


// storage.put('data1','这是数据1修改后的内容');


log(storage.get('data2'))

// 这是数据1修改后的内容
// undefined








toast('阿涛qq/微信：656206105')