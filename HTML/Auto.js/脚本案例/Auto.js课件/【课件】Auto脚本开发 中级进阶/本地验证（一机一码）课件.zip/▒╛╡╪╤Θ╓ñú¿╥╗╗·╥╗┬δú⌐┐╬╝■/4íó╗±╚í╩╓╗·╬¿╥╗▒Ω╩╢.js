



// var uuid = device.fingerprint;

var imei = device.getIMEI()

toast(imei)



// toast('阿涛 QQ/微信：656206105')