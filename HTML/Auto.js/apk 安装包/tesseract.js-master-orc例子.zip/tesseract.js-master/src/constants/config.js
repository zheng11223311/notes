const OEM = require('./OEM');

module.exports = {
  defaultOEM: OEM.DEFAULT,
};
