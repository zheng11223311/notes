id>class>标签>通配符

font-weight:

​	字体粗细100~900之间

text-decoration:

​	overline 上划线

​	underline 下划线

​	line-through 删除线

选择器禁止带有广告的名字