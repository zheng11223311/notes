<?php

//1. js 中有两种注释==相同
//1.1 单行注释
//1.2 多行注释

//2 js 中如何定义变量
// var num=10;

$num=10; //php

//3. js 如何打印内容
// console.log()

echo $num;
echo $num;

//服务器路径 E:\Ajax\wrampserver\wrampserverURL\www 文件放在此目录下(或内) 
// 浏览器输入 ip 地址:127.0.0.1

// 注意点: 后端编写的代码不能直接运行,只能放到服务器对应的文件夹下,通过
// 服务器运行
// 如何通过服务器运行：通过ip 地址找到服务器对应的文件夹，然后再找到对应的文件运行


//4, js 中如何定义集合  echo 不能输出集合
//4.1 数组
//4.2 字典(对象)
// var arr=[1,3,5]

$arr=array(1,3,5);
print_r($arr);
//5. js 中如何获取集合的值?


//5. js 中的分支循环语句
//if / switch / 三目 / for / while

?>